package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class ViewBill extends JFrame {

    ViewBill(String meter) {
        setTitle("View Bills");
        setSize(800, 400);
        setLocation(300, 200);
        getContentPane().setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        JLabel heading = new JLabel("Bill History for Meter: " + meter);
        heading.setFont(new Font("Tahoma", Font.BOLD, 18));
        heading.setHorizontalAlignment(SwingConstants.CENTER);
        heading.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(heading, BorderLayout.NORTH);

        // Updated columns based on your bill table
        String[] columns = {"Bill No", "Month", "Units", "Total Bill", "Payment Status"};

        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        table.setFont(new Font("Tahoma", Font.PLAIN, 14));
        table.setRowHeight(25);

        try {
            Conn c = new Conn();
            System.out.println("Meter passed: " + meter);  // Debugging line

            // Query to fetch bills for this meter number
            String query = "SELECT * FROM bill WHERE meter_no = '" + meter + "'";
            ResultSet rs = c.s.executeQuery(query);

            boolean found = false;  // Flag to check if bills exist for this meter

            // Loop through the result set and populate the table
            while (rs.next()) {
                String billNo = rs.getString("bill_no");
                String month = rs.getString("month");
                String units = rs.getString("units");
                String total = rs.getString("totalbill");
                String paymentStatus = rs.getString("payment_status");

                model.addRow(new Object[]{billNo, month, units, total, paymentStatus});
                found = true;  // Mark that we found bill data
            }

            // If no bill data found, show a message
            if (!found) {
                JOptionPane.showMessageDialog(null, "No bill records found for Meter No: " + meter);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Add the table to the frame
        JScrollPane scroll = new JScrollPane(table);
        add(scroll, BorderLayout.CENTER);

        setVisible(true);
    }
}
