package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CustomerDashboard extends JFrame implements ActionListener {

    String userType;
    String meter;

    // Constructor to initialize userType and meter
    public CustomerDashboard(String userType, String meter) {
        this.userType = userType;
        this.meter = meter;

        setTitle("Customer Dashboard");
        setSize(1200, 700);
        setLocation(100, 30);
        setLayout(new BorderLayout());

        // Sidebar Panel (without images)
        JPanel sidebar = new JPanel();
        sidebar.setBackground(new Color(40, 44, 52));
        sidebar.setLayout(new GridLayout(6, 1, 0, 10));
        sidebar.setPreferredSize(new Dimension(250, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        String[] options = {
            "Update Information", "View Bill", "Pay Bill", "View Information", "Logout"
        };

        // Create buttons for sidebar without images
        for (String label : options) {
            JButton btn = createSidebarButton(label);
            sidebar.add(btn);
        }

        add(sidebar, BorderLayout.WEST);

        // Center Panel (default view)
        JLabel welcome = new JLabel("Welcome to Your Customer Dashboard", SwingConstants.CENTER);
        welcome.setFont(new Font("Serif", Font.BOLD, 26));
        add(welcome, BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    // Method to create sidebar buttons with no images
    private JButton createSidebarButton(String text) {
        JButton button = new JButton(text);

        // Set background color, font, and other button properties
        button.setHorizontalAlignment(SwingConstants.LEFT);  // Align text to the left
        button.setBackground(new Color(42, 87, 141));  // Sidebar background color
        button.setForeground(Color.WHITE);  // White text color
        button.setFont(new Font("SansSerif", Font.BOLD, 16));  // Bold font
        button.setFocusPainted(false);  // Remove border when clicked
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));  // Change cursor to hand
        button.setPreferredSize(new Dimension(230, 50));  // Set button height
        button.addActionListener(this);  // Add action listener for button click

        return button;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String cmd = ae.getActionCommand();

        switch (cmd) {
            case "Update Information":
                // Implement the update info functionality
                new UpdateInformation(meter);
                break;
            case "View Bill":
                // Implement the view bill functionality
                new ViewBill(meter);
                break;
            case "Pay Bill":
                // Implement the pay bill functionality
                new PayBill(meter);
                break;
            case "View Information":
                // Implement the view information functionality
                new ViewInformation(meter);
                break;
            case "Logout":
                setVisible(false);  // Close the dashboard
                new Login();  // Redirect to login screen
                break;
        }
    }

    public static void main(String[] args) {
        new CustomerDashboard("Customer", "12345"); // Test with sample values for customer and meter
    }
}
