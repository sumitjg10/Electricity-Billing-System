package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class CalculateBill extends JFrame implements ActionListener {

    JTextField tfunits;
    JButton next, cancel;
    JLabel lblname, labeladdress, lblbill;
    Choice meternumber, cmonth;

    CalculateBill() {
        setSize(700, 500);
        setLocation(400, 150);

        JPanel p = new JPanel();
        p.setLayout(null);
        p.setBackground(new Color(173, 216, 230));
        add(p);

        JLabel heading = new JLabel("Calculate Electricity Bill");
        heading.setBounds(100, 10, 400, 25);
        heading.setFont(new Font("Tahoma", Font.PLAIN, 24));
        p.add(heading);

        JLabel lblmeternumber = new JLabel("Meter Number");
        lblmeternumber.setBounds(100, 80, 100, 20);
        p.add(lblmeternumber);

        meternumber = new Choice();

        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM customer");
            while (rs.next()) {
                meternumber.add(rs.getString("meter_no"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        meternumber.setBounds(240, 80, 200, 20);
        p.add(meternumber);

        JLabel lblmeterno = new JLabel("Name");
        lblmeterno.setBounds(100, 120, 100, 20);
        p.add(lblmeterno);

        lblname = new JLabel();
        lblname.setBounds(240, 120, 100, 20);
        p.add(lblname);

        JLabel lbladdress = new JLabel("Address");
        lbladdress.setBounds(100, 160, 100, 20);
        p.add(lbladdress);

        labeladdress = new JLabel();
        labeladdress.setBounds(240, 160, 200, 20);
        p.add(labeladdress);

        updateCustomerInfo(meternumber.getSelectedItem());

        meternumber.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent ie) {
                updateCustomerInfo(meternumber.getSelectedItem());
            }
        });

        JLabel lblunits = new JLabel("Units Consumed");
        lblunits.setBounds(100, 200, 100, 20);
        p.add(lblunits);

        tfunits = new JTextField();
        tfunits.setBounds(240, 200, 200, 20);
        p.add(tfunits);

        JLabel lblstate = new JLabel("Month");
        lblstate.setBounds(100, 240, 100, 20);
        p.add(lblstate);

        cmonth = new Choice();
        cmonth.setBounds(240, 240, 200, 20);
        String[] months = {"January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"};
        for (String month : months) {
            cmonth.add(month);
        }
        p.add(cmonth);

        lblbill = new JLabel("Total Bill: ₹0");
        lblbill.setBounds(100, 280, 300, 25);
        lblbill.setFont(new Font("Tahoma", Font.BOLD, 16));
        p.add(lblbill);

        next = new JButton("Submit");
        next.setBounds(120, 350, 100, 25);
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.addActionListener(this);
        p.add(next);

        cancel = new JButton("Cancel");
        cancel.setBounds(250, 350, 100, 25);
        cancel.setBackground(Color.BLACK);
        cancel.setForeground(Color.WHITE);
        cancel.addActionListener(this);
        p.add(cancel);

        setLayout(new BorderLayout());
        add(p, "Center");

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/hicon2.jpg"));
        Image i2 = i1.getImage().getScaledInstance(150, 300, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        add(image, "West");

        getContentPane().setBackground(Color.WHITE);

        setVisible(true);
    }

    private void updateCustomerInfo(String meter) {
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM customer WHERE meter_no = '" + meter + "'");
            if (rs.next()) {
                lblname.setText(rs.getString("name"));
                labeladdress.setText(rs.getString("address"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == next) {
            String meter = meternumber.getSelectedItem();
            String units = tfunits.getText();
            String month = cmonth.getSelectedItem();

            if (units.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter units consumed.");
                return;
            }

            int totalbill = 0;
            int unit_consumed = Integer.parseInt(units);

            try {
                Conn c = new Conn();
                ResultSet rs = c.s.executeQuery("SELECT * FROM tax");
                if (rs.next()) {
                    int costPerUnit = Integer.parseInt(rs.getString("cost_per_unit"));
                    int meterRent = Integer.parseInt(rs.getString("meter_rent"));
                    int serviceCharge = Integer.parseInt(rs.getString("service_charge"));
                    int serviceTax = Integer.parseInt(rs.getString("service_tax"));
                    int swachhCess = Integer.parseInt(rs.getString("swacch_bharat_cess"));
                    int fixedTax = Integer.parseInt(rs.getString("fixed_tax"));

                    totalbill = (unit_consumed * costPerUnit)
                              + meterRent
                              + serviceCharge
                              + serviceTax
                              + swachhCess
                              + fixedTax;
                }
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error calculating bill.");
                return;
            }

            lblbill.setText("Total Bill: ₹" + totalbill);

            // Insert into bill table
            try {
                Conn c = new Conn();
                String query = "INSERT INTO bill (meter_no, month, units, totalbill, payment_status) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement pstmt = c.c.prepareStatement(query);
                pstmt.setString(1, meter);
                pstmt.setString(2, month);
                pstmt.setInt(3, unit_consumed);
                pstmt.setInt(4, totalbill);
                pstmt.setString(5, "Not Paid");

                int rows = pstmt.executeUpdate();

                if (rows > 0) {
                    JOptionPane.showMessageDialog(null, "Bill Generated Successfully\nTotal Bill: ₹" + totalbill);
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to insert bill into database.");
                }

            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error inserting bill into database.");
            }

        } else {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new CalculateBill();
    }
}
