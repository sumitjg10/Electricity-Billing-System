package electricity.billing.system;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import java.sql.*;
import java.awt.event.*;

public class DepositDetails extends JFrame implements ActionListener {

    Choice meternumber, cmonth;
    JTable table;
    JButton search, print;
    DefaultTableModel model;

    DepositDetails() {
        super("Deposit Details");

        setSize(700, 700);
        setLocation(400, 100);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel lblmeternumber = new JLabel("Search By Meter Number");
        lblmeternumber.setBounds(20, 20, 150, 20);
        add(lblmeternumber);

        meternumber = new Choice();
        meternumber.setBounds(180, 20, 150, 20);
        add(meternumber);

        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT meter_no FROM customer");
            while (rs.next()) {
                meternumber.add(rs.getString("meter_no"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading meter numbers: " + e.getMessage());
            e.printStackTrace();
        }

        JLabel lblmonth = new JLabel("Search By Month");
        lblmonth.setBounds(400, 20, 100, 20);
        add(lblmonth);

        cmonth = new Choice();
        cmonth.setBounds(520, 20, 150, 20);
        String[] months = { "January", "February", "March", "April", "May", "June", "July", "August", "September",
                "October", "November", "December" };
        for (String month : months) {
            cmonth.add(month);
        }
        add(cmonth);

        // Creating the table with an empty model
        model = new DefaultTableModel();
        table = new JTable(model);

        loadTableData(); // Load all data initially

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(0, 100, 700, 500);
        add(sp);

        search = new JButton("Search");
        search.setBounds(20, 70, 80, 20);
        search.addActionListener(this);
        add(search);

        print = new JButton("Print");
        print.setBounds(120, 70, 80, 20);
        print.addActionListener(this);
        add(print);

        setVisible(true);
    }

    private void loadTableData() {
        String query = "SELECT * FROM bill";
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery(query);
            populateTable(rs);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void populateTable(ResultSet rs) throws SQLException {
        model.setRowCount(0); // Clear previous data
        model.setColumnCount(0); // Clear previous columns

        ResultSetMetaData metaData = rs.getMetaData();
        int columnCount = metaData.getColumnCount();

        // Adding column names
        for (int i = 1; i <= columnCount; i++) {
            model.addColumn(metaData.getColumnName(i));
        }

        // Adding rows
        while (rs.next()) {
            Object[] rowData = new Object[columnCount];
            for (int i = 1; i <= columnCount; i++) {
                rowData[i - 1] = rs.getObject(i);
            }
            model.addRow(rowData);
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == search) {
            String query = "SELECT * FROM bill WHERE meter_no = '" + meternumber.getSelectedItem()
                    + "' AND month = '" + cmonth.getSelectedItem() + "'";
            try 
            {
                Conn c = new Conn();
                ResultSet rs = c.s.executeQuery(query);
                populateTable(rs);
            } 
            catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Search Error: " + e.getMessage());
                e.printStackTrace();
            }
            
        } 
        else 
        {
            try {
                table.print();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Print Error: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new DepositDetails();
    }
}
