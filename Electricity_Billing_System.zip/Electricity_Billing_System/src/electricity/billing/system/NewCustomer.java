package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.util.regex.Pattern;

public class NewCustomer extends JFrame implements ActionListener {

    JTextField tfname, tfaddress, tfstate, tfcity, tfemail;
    JButton next, cancel;
    JLabel lblmeter;

    NewCustomer() {
        setSize(700, 500);
        setLocation(400, 200);

        JPanel p = new JPanel();
        p.setLayout(null);
        p.setBackground(new Color(173, 216, 230));
        add(p);

        JLabel heading = new JLabel("New Customer");
        heading.setBounds(180, 10, 200, 25);
        heading.setFont(new Font("Tahoma", Font.PLAIN, 24));
        p.add(heading);

        JLabel lblname = new JLabel("Customer Name");
        lblname.setBounds(100, 80, 100, 20);
        p.add(lblname);

        tfname = new JTextField();
        tfname.setBounds(240, 80, 200, 20);
        p.add(tfname);

        JLabel lblmeterno = new JLabel("Meter Number");
        lblmeterno.setBounds(100, 120, 100, 20);
        p.add(lblmeterno);

        lblmeter = new JLabel("");
        lblmeter.setBounds(240, 120, 100, 20);
        p.add(lblmeter);

        Random ran = new Random();
        long number = ran.nextLong() % 1000000;
        lblmeter.setText("" + Math.abs(number));

        JLabel lbladdress = new JLabel("Address");
        lbladdress.setBounds(100, 160, 100, 20);
        p.add(lbladdress);

        tfaddress = new JTextField();
        tfaddress.setBounds(240, 160, 200, 20);
        p.add(tfaddress);

        JLabel lblcity = new JLabel("City");
        lblcity.setBounds(100, 200, 100, 20);
        p.add(lblcity);

        tfcity = new JTextField();
        tfcity.setBounds(240, 200, 200, 20);
        p.add(tfcity);

        JLabel lblstate = new JLabel("State");
        lblstate.setBounds(100, 240, 100, 20);
        p.add(lblstate);

        tfstate = new JTextField();
        tfstate.setBounds(240, 240, 200, 20);
        p.add(tfstate);

        JLabel lblemail = new JLabel("Email");
        lblemail.setBounds(100, 280, 100, 20);
        p.add(lblemail);

        tfemail = new JTextField();
        tfemail.setBounds(240, 280, 200, 20);
        p.add(tfemail);

        next = new JButton("Next");
        next.setBounds(120, 390, 100, 25);
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.addActionListener(this);
        p.add(next);

        cancel = new JButton("Cancel");
        cancel.setBounds(250, 390, 100, 25);
        cancel.setBackground(Color.BLACK);
        cancel.setForeground(Color.WHITE);
        cancel.addActionListener(this);
        p.add(cancel);

        setLayout(new BorderLayout());

        add(p, "Center");

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/hicon1.jpg"));
        Image i2 = i1.getImage().getScaledInstance(150, 300, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        add(image, "West");

        getContentPane().setBackground(Color.WHITE);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == next) {
            String name = tfname.getText();
            String meter = lblmeter.getText();
            String address = tfaddress.getText();
            String city = tfcity.getText();
            String state = tfstate.getText();
            String email = tfemail.getText();

            try {
                // Validate customer name
                if (!Pattern.matches("^[A-Za-z\\s]+$", name)) {
                    JOptionPane.showMessageDialog(this, "Invalid customer name");
                    tfname.setText("");
                    tfname.grabFocus();
                    return; // Stop execution to allow user to correct the input
                }

                // Validate email format
                if (!Pattern.matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$", email)) {
                    JOptionPane.showMessageDialog(this, "Invalid email format.");
                    tfemail.setText("");
                    tfemail.grabFocus();
                    return; // Stop execution to allow user to correct the input
                }

                // Check if address is empty
                if (address.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Address cannot be empty.");
                    tfaddress.grabFocus();
                    return; // Stop execution to allow user to correct the input
                }

                // Check if state is empty
                if (state.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "State cannot be empty.");
                    tfstate.grabFocus();
                    return; // Stop execution to allow user to correct the input
                }

                // Check if city is empty
                if (city.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "City cannot be empty.");
                    tfcity.grabFocus();
                    return; // Stop execution to allow user to correct the input
                }

                // If all validations pass, proceed to insert data into the database
                String query1 = "INSERT INTO customer (name, meter_no, address, city, state, email, password, username) " +
                                "VALUES('" + name + "', '" + meter + "', '" + address + "', '" + city + "', '" + state + "', '" + email + "', '', '')";

                Conn c = new Conn();
                c.s.executeUpdate(query1);

                JOptionPane.showMessageDialog(null, "Customer Details Added Successfully");
                setVisible(false);
                // Replace MeterInfo(meter) with your next frame/page class constructor call
                // new MeterInfo(meter); // Uncomment this if you have this constructor ready

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == cancel) {
            setVisible(false); // Close the current window
        }
    }

    public static void main(String[] args) {
        new NewCustomer();
    }
}
