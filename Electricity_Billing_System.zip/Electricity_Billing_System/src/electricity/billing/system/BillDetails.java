package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class BillDetails extends JFrame{
    
//     JButton  print;
   
    BillDetails(String meter) {
        
        setSize(700, 650);
        setLocation(400, 150);
        
        getContentPane().setBackground(Color.WHITE);
        
        JTable table = new JTable();
        
        try {
            Conn c = new Conn();
            String query = "select * from bill where meter_no = '"+ meter +"'";
            var rs = c.s.executeQuery(query);
            
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException e) {
        }
        
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(0, 0, 700, 650);
        add(sp);
        
        setVisible(true);
        
//         print = new JButton("Print");
//        print.setBounds(120, 70, 80, 20);
//        print.addActionListener(this);
//        add(print);
    }

    public static void main(String[] args) {
        new BillDetails("");
    }
}