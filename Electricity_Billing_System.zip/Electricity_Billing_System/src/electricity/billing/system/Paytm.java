package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Paytm extends JFrame implements ActionListener {

    String meter;
    JButton back;

    Paytm(String meter) {
        this.meter = meter;

        // Check if meter is empty, if yes, show an error message and return
        if (meter == null || meter.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Invalid Meter Number!");
            return; // Stop further execution
        }

        JEditorPane j = new JEditorPane();
        j.setEditable(false);

        try {
            j.setPage("https://paytm.com/online-payments");
        } catch (Exception e) {
            j.setContentType("text/html");
            j.setText("<html>Could not load Paytm page. Please try again.<html>");
        }

        JScrollPane pane = new JScrollPane(j);
        add(pane);

        back = new JButton("Back");
        back.setBounds(640, 20, 80, 30);
        back.addActionListener(this);
        add(back);

        setSize(800, 600);
        setLocation(400, 150);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
        new PayBill(meter); // Navigate back to the PayBill window after payment
    }

    public static void main(String[] args) {
        // Test Paytm window with a valid meter number
        String meter = "123456";  // Replace with a valid meter number
        new Paytm(meter);
    }
}
