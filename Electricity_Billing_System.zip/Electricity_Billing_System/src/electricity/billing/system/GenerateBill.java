package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class GenerateBill extends JFrame implements ActionListener {

    JTextArea area;
    JButton generateBtn;
    Choice meterChoice, monthChoice;

    public GenerateBill() {
        setTitle("Generate Electricity Bill");
        setSize(600, 700);
        setLocation(500, 20);
        setLayout(new BorderLayout());

        // Top panel for inputs
        JPanel top = new JPanel(new GridLayout(2, 2, 10, 10));
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        top.add(new JLabel("Select Meter Number:"));
        meterChoice = new Choice();
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT meter_no FROM customer");
            while (rs.next()) {
                meterChoice.add(rs.getString("meter_no"));
            }
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        top.add(meterChoice);

        top.add(new JLabel("Select Month:"));
        monthChoice = new Choice();
        String[] months = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        };
        for (String m : months) monthChoice.add(m);
        top.add(monthChoice);

        add(top, "North");

        // Bill display area
        area = new JTextArea();
        area.setFont(new Font("Monospaced", Font.PLAIN, 12));
        area.setEditable(false);
        area.setText("\n\t---- Electricity Bill Viewer ----\n\nSelect meter and month then click Generate.");
        add(new JScrollPane(area), "Center");

        // Generate Button
        generateBtn = new JButton("Generate Bill");
        generateBtn.setFont(new Font("SansSerif", Font.BOLD, 16));
        generateBtn.setBackground(Color.BLACK);
        generateBtn.setForeground(Color.WHITE);
        generateBtn.addActionListener(this);
        add(generateBtn, "South");

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String meter = meterChoice.getSelectedItem();
        String month = monthChoice.getSelectedItem();

        try {
            Conn c = new Conn();

            // Fetch customer details
            ResultSet rs1 = c.s.executeQuery("SELECT * FROM customer WHERE meter_no = '" + meter + "'");
            String name = "", address = "", state = "", email = "";
            if (rs1.next()) {
                name = rs1.getString("name");
                address = rs1.getString("address");
                state = rs1.getString("state");
                email = rs1.getString("email");
            }

            // Fetch bill details
            ResultSet rs2 = c.s.executeQuery("SELECT * FROM bill WHERE meter_no = '" + meter + "' AND month = '" + month + "'");
            if (rs2.next()) {
                StringBuilder sb = new StringBuilder();
                sb.append("\n\tElectricity Bill - " + month + " 2025\n");
                sb.append("--------------------------------------------------\n");
                sb.append(" Meter Number   : ").append(meter).append("\n");
                sb.append(" Name           : ").append(name).append("\n");
                sb.append(" Address        : ").append(address).append("\n");
                sb.append(" State          : ").append(state).append("\n");
                sb.append(" Email          : ").append(email).append("\n");
                sb.append("--------------------------------------------------\n");
                sb.append(" Units Consumed : ").append(rs2.getString("units")).append("\n");
                sb.append(" Total Bill     : ₹").append(rs2.getString("totalbill")).append("\n");
                sb.append("--------------------------------------------------\n");
                sb.append(" Please pay your bill before the due date.\n");
                sb.append("\n\tThank you for using EBS!");
                area.setText(sb.toString());
            } else {
                area.setText("No bill found for Meter No: " + meter + " in " + month);
            }

            c.close();

        } catch (Exception e) {
            e.printStackTrace();
            area.setText("Error generating bill.");
        }
    }
}
