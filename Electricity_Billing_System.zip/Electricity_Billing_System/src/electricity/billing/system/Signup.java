package electricity.billing.system;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Signup extends JFrame implements ActionListener, ItemListener {

    Choice accountType, meterChoice;
    JTextField username, name, password;
    JButton create, back;

    Signup() {
        setTitle("Signup");
        setBounds(450, 150, 700, 500);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(30, 30, 620, 400);
        panel.setBorder(new TitledBorder(new LineBorder(new Color(173, 216, 230), 2), "Signup", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(172, 216, 230)));
        panel.setBackground(Color.WHITE);
        panel.setLayout(null);
        add(panel);

        JLabel lblTitle = new JLabel("Create Account");
        lblTitle.setBounds(220, 10, 200, 30);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblTitle.setForeground(new Color(34, 139, 34));
        panel.add(lblTitle);

        JLabel lblType = new JLabel("Account Type");
        lblType.setBounds(100, 50, 140, 20);
        lblType.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblType.setForeground(Color.GRAY);
        panel.add(lblType);

        accountType = new Choice();
        accountType.add("Customer");
        accountType.add("Admin");
        accountType.setBounds(260, 50, 200, 25);
        accountType.addItemListener(this);
        panel.add(accountType);

        JLabel lblUsername = new JLabel("Username");
        lblUsername.setBounds(100, 90, 140, 20);
        lblUsername.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblUsername.setForeground(Color.GRAY);
        panel.add(lblUsername);

        username = new JTextField();
        username.setBounds(260, 90, 200, 25);
        panel.add(username);

        JLabel lblName = new JLabel("Name");
        lblName.setBounds(100, 130, 140, 20);
        lblName.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblName.setForeground(Color.GRAY);
        panel.add(lblName);

        name = new JTextField();
        name.setBounds(260, 130, 200, 25);
        panel.add(name);

        JLabel lblPassword = new JLabel("Password");
        lblPassword.setBounds(100, 170, 140, 20);
        lblPassword.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblPassword.setForeground(Color.GRAY);
        panel.add(lblPassword);

        password = new JTextField();
        password.setBounds(260, 170, 200, 25);
        panel.add(password);

        JLabel lblMeter = new JLabel("Meter Number");
        lblMeter.setBounds(100, 210, 140, 20);
        lblMeter.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblMeter.setForeground(Color.GRAY);
        panel.add(lblMeter);

        meterChoice = new Choice();
        meterChoice.setBounds(260, 210, 200, 25);
        panel.add(meterChoice);

        create = new JButton("Create");
        create.setBackground(new Color(34, 139, 34));
        create.setForeground(Color.WHITE);
        create.setBounds(150, 280, 120, 30);
        create.addActionListener(this);
        panel.add(create);

        back = new JButton("Back");
        back.setBackground(new Color(220, 20, 60));
        back.setForeground(Color.WHITE);
        back.setBounds(300, 280, 120, 30);
        back.addActionListener(this);
        panel.add(back);

        loadMeterNumbers();
        toggleMeterField(true);  // Customer by default
        setVisible(true);
    }

    private void loadMeterNumbers() {
        try {
            Conn c = new Conn();
            // Just load all meter numbers from the customer table
            ResultSet rs = c.s.executeQuery("SELECT meter_no FROM customer");
            meterChoice.removeAll();
            while (rs.next()) {
                meterChoice.add(rs.getString("meter_no"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void toggleMeterField(boolean show) {
        meterChoice.setEnabled(show);
    }

    public void itemStateChanged(ItemEvent e) {
        boolean isCustomer = accountType.getSelectedItem().equals("Customer");
        toggleMeterField(isCustomer);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == create) {
            String acctype = accountType.getSelectedItem();
            String user = username.getText();
            String uname = name.getText();
            String pass = password.getText();

            if (user.isEmpty() || uname.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill all the fields");
                return;
            }

            try {
                Conn c = new Conn();
                String query = "";

                if (acctype.equals("Admin")) {
                    query = "INSERT INTO login (username, name, password, user) VALUES ('" + user + "', '" + uname + "', '" + pass + "', 'Admin')";
                } else {
                    String meter = meterChoice.getSelectedItem();
                    query = "INSERT INTO login (meter_no, username, name, password, user) VALUES ('" + meter + "', '" + user + "', '" + uname + "', '" + pass + "', 'Customer')";
                }

                c.s.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Account Created Successfully");

                setVisible(false);
                new Login();

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (ae.getSource() == back) {
            setVisible(false);
            new Login();
        }
    }

    public static void main(String[] args) {
        new Signup();
    }
}
