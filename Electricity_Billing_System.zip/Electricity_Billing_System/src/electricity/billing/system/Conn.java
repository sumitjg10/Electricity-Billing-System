






package electricity.billing.system;

import java.sql.*;

public class Conn {
    Connection c;
    Statement s;

    public Conn() {
        try {
              c = DriverManager.getConnection("jdbc:mysql://localhost:3306/electricity_billing_system","root","Sumit@123");
            s = c.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ✅ Add this method to allow safe closing
    public void close() {
        try {
            if (s != null && !s.isClosed()) {
                s.close();
            }
            if (c != null && !c.isClosed()) {
                c.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
