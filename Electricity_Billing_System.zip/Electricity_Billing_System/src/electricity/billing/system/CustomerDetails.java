package electricity.billing.system;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.sql.*;

public class CustomerDetails extends JFrame implements ActionListener {

    JTable table;
    JButton print;

    CustomerDetails() {
        super("Customer Details");

        setSize(1200, 650);
        setLocation(200, 150);

        table = new JTable();
        loadCustomerData(); // Load data into the table

        JScrollPane sp = new JScrollPane(table);
        add(sp, BorderLayout.CENTER);

        print = new JButton("Print");
        print.addActionListener(this);
        add(print, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void loadCustomerData() {
        try {
            Conn c = new Conn();
            String query = "SELECT * FROM customer";
            ResultSet rs = c.s.executeQuery(query);
            ResultSetMetaData metaData = rs.getMetaData();

            // Create table model
            DefaultTableModel model = new DefaultTableModel();
            table.setModel(model);

            // Add column names
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                model.addColumn(metaData.getColumnName(i));
            }

            // Add rows
            while (rs.next()) {
                Object[] rowData = new Object[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    rowData[i - 1] = rs.getObject(i);
                }
                model.addRow(rowData);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            table.print();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Print Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new CustomerDetails();
    }
}
