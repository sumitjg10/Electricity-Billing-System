package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Project extends JFrame implements ActionListener {

    String userType;
    String meter;

    // Updated constructor to accept both userType and meter
    public Project(String userType, String meter) {
        this.userType = userType;
        this.meter = meter;
        setTitle("Electricity Billing System - " + userType);
        setSize(1200, 700);
        setLocation(100, 30);
        setLayout(new BorderLayout());

        // Sidebar Panel
        JPanel sidebar = new JPanel();
        sidebar.setBackground(new Color(40, 44, 52));
        sidebar.setLayout(new GridLayout(6, 1, 0, 10));
        sidebar.setPreferredSize(new Dimension(250, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        String[] options = {
            "New Customer", "Customer Details", "Deposit Details",
            "Calculate Bill", "Generate Bill", "Logout"
        };

        for (String label : options) {
            JButton btn = new JButton(label);
            btn.setBackground(new Color(60, 63, 65));
            btn.setForeground(Color.WHITE);
            btn.setFont(new Font("SansSerif", Font.BOLD, 16));
            btn.setFocusPainted(false);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.addActionListener(this);
            sidebar.add(btn);
        }

        add(sidebar, BorderLayout.WEST);

        // Center Panel (default view)
        JLabel welcome = new JLabel("Welcome to Electricity Billing System " + userType + " Dashboard", SwingConstants.CENTER);
        welcome.setFont(new Font("Serif", Font.BOLD, 26));
        add(welcome, BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String cmd = ae.getActionCommand();

        switch (cmd) {
            case "New Customer":
                new NewCustomer();
                break;
            case "Customer Details":
                new CustomerDetails();
                break;
            case "Deposit Details":
                new DepositDetails();
                break;
            case "Calculate Bill":
                new CalculateBill();
                break;
            case "Generate Bill":
                new GenerateBill(); // GenerateBill with dropdown selection
                break;
            case "Logout":
                setVisible(false);
                new Login();
                break;
        }
    }

    public static void main(String[] args) {
        new Project("Admin", ""); // Test with Admin and empty meter value
    }
}
