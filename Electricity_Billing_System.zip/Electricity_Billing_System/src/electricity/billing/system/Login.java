package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener {

    JButton login, cancel, signup;
    JTextField username;
    JPasswordField passwordField;
    Choice loggingIn;

    Login() {
        super("Login Page");
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel lblusername = new JLabel("Username");
        lblusername.setBounds(300, 20, 100, 20);
        add(lblusername);

        username = new JTextField();
        username.setBounds(400, 20, 150, 20);
        add(username);

        JLabel lblpassword = new JLabel("Password");
        lblpassword.setBounds(300, 60, 100, 20);
        add(lblpassword);

        passwordField = new JPasswordField();
        passwordField.setBounds(400, 60, 150, 20);
        add(passwordField);

        JLabel loggingInAs = new JLabel("Login as");
        loggingInAs.setBounds(300, 100, 100, 20);
        add(loggingInAs);

        loggingIn = new Choice();
        loggingIn.add("Admin");
        loggingIn.add("Customer");
        loggingIn.setBounds(400, 100, 150, 20);
        add(loggingIn);

        login = new JButton("Login");
        login.setBounds(330, 160, 100, 20);
        login.addActionListener(this);
        add(login);

        cancel = new JButton("Cancel");
        cancel.setBounds(450, 160, 100, 20);
        cancel.addActionListener(this);
        add(cancel);

        signup = new JButton("Signup");
        signup.setBounds(380, 200, 100, 20);
        signup.addActionListener(this);
        add(signup);

        setSize(700, 300);
        setLocation(400, 200);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == login) {
            String susername = username.getText();
            String spassword = new String(passwordField.getPassword());
            String user = loggingIn.getSelectedItem();

            Conn c = null;
            try {
                c = new Conn();
                String query = "SELECT * FROM login WHERE username = '" + susername + "' AND password = '" + spassword + "' AND user = '" + user + "'";
                ResultSet rs = c.s.executeQuery(query);

                if (rs.next()) {
                    String meter = rs.getString("meter_no");
                    setVisible(false);

                    if (user.equals("Admin")) {
                        new Project(user, meter); // Admin Dashboard
                    } else {
                        new CustomerDashboard(user, meter); // Fixed: pass both userType and meter
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Login");
                }

            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            } finally {
                if (c != null) {
                    c.close();
                }
                username.setText("");
                passwordField.setText("");
            }

        } else if (ae.getSource() == cancel) {
            setVisible(false); // Close login window
        } else if (ae.getSource() == signup) {
            setVisible(false); // Close login
            new Signup(); // Open signup page
        }
    }

    public static void main(String[] args) {
        new Login(); // Launch login page
    }
}
