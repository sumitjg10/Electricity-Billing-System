package electricity.billing.system;

import javax.swing.*;
import java.awt.*;

public class MeterInfo extends JFrame {
    
    JLabel lblMeterInfo;

    MeterInfo(String meter) {
        setSize(700, 500);
        setLocation(400, 200);
        
        JPanel p = new JPanel();
        p.setLayout(null);
        p.setBackground(new Color(173, 216, 230));
        add(p);
        
        JLabel heading = new JLabel("Meter Information for Meter No: " + meter);
        heading.setBounds(180, 10, 300, 25);
        heading.setFont(new Font("Tahoma", Font.PLAIN, 24));
        p.add(heading);

        // You can add more fields for meter information here...

        setLayout(new BorderLayout());
        add(p, "Center");

        getContentPane().setBackground(Color.WHITE);

        setVisible(true);
    }

    public static void main(String[] args) {
        // This is just to test the MeterInfo screen.
        new MeterInfo("123456");
    }
}
